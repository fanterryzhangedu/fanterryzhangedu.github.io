#!/usr/bin/perl
use strict;

#declare subroutines
sub FindPhysicalPath($$);	#find the physical path for two nodes, using $gPath, $gComm
sub DISTANCE(@@);		#calcute the distance^2 between two nodes
sub get_dist($);		#get the dist array, find all one bits
sub getWeight($);		#get the bit weight, find the weight of all one bits
sub printArray;			#print an Array
sub print_help;			#print help
sub getHW($);			#get the Hamming Weight
sub getOneSetting();		#simulation for one setting
sub TryPair();			#simulation for one pair
sub getNoneZeroBits($);
sub getStage($@);
sub getCollision(\@\@);	#get the probability for the collision

#Global varibale definition
my $m = 6; 			#number of bits in the address space
my $size;  			#total number of nodes
my $sizemask;
my $p = 0.01; 			#node failure probability
my $opt_f = "";			#input file
my $D = 10;			#Density of nodes (/per unit^2)
my $T = 1;			#Transmition range (/per unit)
my $a;				#Side of the square
my $b = 1;			#Group base.
my $numG;			#number of groups
my $opt_r = 0; 
my $r = 1;			#Total number of pairs to choose, r = 0 : check all pairs
my $opt_n = 0; 			#number of simulations for each pair
my $opt_l = 0; 
my $l = 1;			#outgoing degree
my $opt_try = 0; 
my $try = 1;			#for each node, how many tries once it fails to forward the msg

my %log_2 = (			#hash table loopup to do module operation
	1 => 0,
	2 => 1,
	4 => 2,
	8 => 3,
	16 => 4,
	32 => 5,
	64 => 6,
	128 => 7,
	256 => 8,
	512 => 9,
	1024 => 10,
	2048 => 11,
	4096 => 12,
	8192 => 13,
	16384 => 14,
	32768 => 15,
	65536 => 16
);

my @num_tests = 
(0, 	100, 	100, 	100, 	240, 
1200, 	2500, 	5000, 	10000, 	10000, 
10000, 10000, 10000); 

my @array_path;		#Table for all the physical path info
			#@array_path[$i][$j][$k]
			#	$i: source node id
			#	$j: the j_th node which preshare a key with $j. $j=[1..2$m-1]
			#	$k=0, [$k] desination id
			#	$k=1, [$k] the path is alive or not
			#	$k=2, [$k] the communication cost along the path = hops of the path
			#	$k=3, [$k] an array will the all nodes along the path except the source node
my @array_nodes;	#Array for all the node info
			#Table for all the node info
			#@array_nodes[$i][$j]
			#	$i: node id
			#	$j: node info
			#	$j=0, [$j] x position
			#	$j=1, [$j] y position
			#	$j=2, [$j] the node is alive or not
			#	$j=3, [$j] comm cost on this node
my @gNodeCost;
my @gPath;
my $gComm;
my %gSelectedPath;
my @gAllPathsInOneSetting;
my $gSettingCost;
my $gSettingAlive;
my $gHalfTableSize;
my @gSettingVisitedNodes; 		#visited physical nodes in one setting
my @gACKPhiNodes;
my @gNeighbours;
my %gVisited_node=();
my $gFoundACK;

#user input
while ($#ARGV >= 0 and $ARGV[0] =~ /^-/) {
	$_ = shift @ARGV;
	/^-m(\d+)/ and ($m = $1, next);			#address space
	/^-d(\d+)/i and ($D = $1, next);		#node density
	/^-p(\d+.\d+)/ and ($p = $1, next);		#node failure probability
	/^-b(\d+)/i and ($b = $1, next);		#group base
	/^-f(.+)/ and ($opt_f = $1, next);		#input configuration file
	/^-r(\d+)/ and ($r = $1, next);			#number of paires
	/^-n(\d+)/ and ($opt_n = $1, next);		#number of simulations for each pair
	/^-l(\d+)/ and ($opt_l = $l = $1, next);	#outgoing degree
	/^-try(\d+)/ and ($opt_try = $try = $1, next);	
	/^-h$/ and print_help();			#help
	die "Unknown option '$_'\n";
}

die "m cannot be greater than 16.\n" if ($m > 16);

my @CurrentPath = ();
my $src;
my $dst;
my %gDist;
my @gWeight;
my $clockwise;

if ($opt_f eq "") {

    $size = 1 << $m;
    $sizemask = $size - 1;
    $a = sqrt($size/$D);
    $numG = int(($m + $b - 1) / $b); 		#get the number of groups. $b=1, then $numG=$m, else $numG= [$m/$b]
    $gHalfTableSize = (1 << $b) * $numG;  

    printf("config=$m $D $p $b $l $try %.5f\n", $a);

    # Generate the network
    foreach (0..$size-1) {
	my @node = ();
	$node[0] = rand($a) ; #random generate x,y position
	$node[1] = rand($a) ; 
	$node[2] = (rand(1)>$p)? 1:0; #alive
	$array_nodes[$_] = \@node;
	printf("$_(%.5f,%.5f,%d)\n", $array_nodes[$_][0], $array_nodes[$_][1], $array_nodes[$_][2]);
    }

    # find out the alive neighbours for each node
    foreach (0..$size-1) {
	$gNeighbours[$_] = [ ];
    }

    foreach  my $i (0..$size-1) {
	next if (! $array_nodes[$i][2]);  # not alive
	foreach  my $j ($i+1..$size-1) {
		next if (! $array_nodes[$j][2]);
		my $r;
		if (($r = DISTANCE($i, $j)) <= $T) {
			# print "$r = \n";
			push @{$gNeighbours[$i]}, $j;
			push @{$gNeighbours[$j]}, $i;
		}
	}
    }

    #foreach (0..$size-1) {
    #	print "$_: ", $#{$gNeighbours[$_]}, " ";
    #	printArray(@{$gNeighbours[$_]});
    #	print "\n";
    #}

    # Generate the cost of communications on each logic hop 
    foreach  my $i (0..$size-1) {
	    #my $k1 = 0;		# index of the group
	    #my $k2 = 0;		# index of node in the group
	foreach  my $j (0..$gHalfTableSize*2-1) {
		# 0..$gHalfTableSize - 1 : clockwise  + 
		# Otherwise: counter-clockwise -
		my $dstid;
		my $dis;
		my ($k1, $k2, $k);
		
		$k= ($j<$gHalfTableSize) ? $j : $j-$gHalfTableSize;
		$k1 = ($k >> $b);
		$k2 = $k - ($k1 << $b);
		$dis = ($k2) << ($b * $k1);
		$dstid = (($j<$gHalfTableSize) ? ($i + $dis) : ($i - $dis)) & $sizemask;

		if (!$k2) {
			$array_path[$i][$j]= [ $dstid, 1, 0, [] ]; 
		}
		else {

			@gPath = ();
			$gComm = 0;
			my $found = FindPhysicalPath($i, $dstid);
			my @lPath = @gPath;
			$array_path[$i][$j]= [ $dstid, $found, $gComm, \@lPath ]; 
		}
		printf("$i:$dstid:%d:%d:", $array_path[$i][$j][1], $array_path[$i][$j][2]);
		printArray(@{$array_path[$i][$j][3]});
		print "\n";	
        }
	#print "--------------------\n";
    }
}else{	#read the configurations from the file
	my $left;
	my $right;
	open(INFILE,  $opt_f) or die "Can't open input file: $opt_f!";
	while (<INFILE>) {     # assigns each line in turn to $_
		last if (/^;/);
		print $_;
		if ($_ =~ /^config=(.+)/){
			my @parameters = split(" ", $1);
			$m = shift @parameters;
			$D = shift @parameters;
			$p = shift @parameters;
			$b = shift @parameters;
			$l = shift @parameters;
			$try = shift @parameters;
			$a = shift @parameters;
			$size = 1 << $m;
			$sizemask = $size - 1;
    			$numG = int(($m + $b - 1) / $b);
    			$gHalfTableSize = (1 << $b) * $numG;  

			$l = $opt_l if ($opt_l);
			$try = $opt_try if ($opt_try);

    			printf("config=$m $D $p $b $l $try %.5f\n", $a);

			#($count++, next) if ($left =~ /nt/);
			#($sum_rp += $right, next) if ($left =~ /rp/);
			#($sum_ca += $right, next) if ($left =~ /ca/);
			next;
		};
		if ($_ =~ /^(\d+)\(([^,]+),([^,]+),(0|1)\)/) {
			$array_nodes[$1] = [$2, $3, $4];
			next;
			# printf("$1(%.5f,%.5f,%d)\n", $array_nodes[$1][0], $array_nodes[$1][1], $array_nodes[$1][2]);
		};
		if ($_ =~ /:/){
			my @phicalpathinfo = split (":", $_);
			my $cur_node = $phicalpathinfo[0];
			my $next_node = $phicalpathinfo[1];
			my $path_alive = $phicalpathinfo[2];
			my $comm_cost = $phicalpathinfo[3];
			my @path = split (" ", $phicalpathinfo[4]);
			push @{$array_path[$cur_node]}, [$next_node, $path_alive, $comm_cost, \@path ];
			# printf("$cur_node:$next_node:%d:%d:", $array_path[$cur_node][$index_next_node][1], $array_path[$cur_node][$index_next_node][2]);
			# printArray(@{$array_path[$cur_node][$index_next_node][3]});
			# print "\n";				
		};
	}
	close INFILE;
}

if ($r) {
	
   my $count_ACK=0;
   foreach (0..$r-1) { 
	$src=int(rand($size));
	while ($array_nodes[$src][2] == 0) {$src=int(rand($size))};
	$dst=int(rand($size));
	#perl simulation9.pl -p0.01 -l1 -m12 -D20 -r10000 >01_1.txt
	#$src=46;
	#$dst=24;
	#$clockwise=1;
	#test
	while ($dst == $src or $array_nodes[$dst][2] == 0) {$dst=int(rand($size))};
	print ";$_\n";
	
	#get the ACK info
	@gACKPhiNodes = ();
	@gPath = ();
	$gFoundACK = FindPhysicalPath($dst, $src);
	@gACKPhiNodes = @gPath;  #the src and dst are not included
	push @gACKPhiNodes, $dst;
	$count_ACK ++ if $gFoundACK;
	
	TryPair(); 
   }
   printf("The percentage to find an ACK in $r pairs is %.5f\n", $count_ACK/$r);
}
else {
    foreach (0..$size-1) 
    {
	$src = $_;
	next if ($array_nodes[$src][2] == 0);
	foreach (0..$size-1) {
		$dst = $_;
		next if ($src == $dst or $array_nodes[$dst][2] == 0); 
		TryPair();
	}
    }
}
@gNeighbours = (); #release the arry resource

sub TryPair()
{
	# $src = 51; $dst = 18;
	print "#$src $dst\n";
	# calculate the distance.
	my $d1 = ($dst-$src)>0 ? ($dst-$src): ($dst+$size-$src); #clockwise
	my $d2 = ($src-$dst)>0 ? ($src-$dst): ($src+$size-$dst); #couter-clockwise
	
	#follow the shortest path
	my $d = ($d1 < $d2) ? $d1 : $d2;
	$clockwise = $d1 < $d2 ? 1 : 0;
	#get_dist($d);	# find all the 1 bits in $d1;
	getWeight($d);
	my $hw=$#gWeight+1; 
	print("hw=$hw\n");
	
	my $ntests = $opt_n;
	if (!$ntests) {
		$ntests = $num_tests[$hw]; 
		$ntests = $num_tests[$#num_tests] if ($hw > $#num_tests);
	}
	
	#reset all counters
	my $num_alive_settings = 0;
	my $num_insecure_ACK = 0;
	my $num_secure_ACK = 0;
	my $num_no_ACK= 0;
	my $cost_pair = 0;
	my $cost_prob = 0;
	my $result =0;
	my $dist_sd = 0;
	@gNodeCost = (); 	# cost for every node
	
	foreach (1..$ntests) { #try one pair for $ntests times, each time generate a setting
		#print "----------------\n";
		$gSettingAlive = 0;
		$gSettingCost = 0;
		@gSettingVisitedNodes = ();
		%gVisited_node=(); 			#clean the visited nodes list
		$gVisited_node{$src} = \@gWeight; 	#initialize
		$result =0;
		
		my $i =1;
		while (($gSettingAlive == 0) and ($i <= $try)){	#$try is the number of repetive tries
			getOneSetting();
			$num_alive_settings ++ if $gSettingAlive;
			delete $gVisited_node{$src} if (exists $gVisited_node{$src}); #remove src
			delete $gVisited_node{$dst} if (exists $gVisited_node{$dst}); #remove dst
			@gSettingVisitedNodes = keys %gVisited_node;
			if ($gSettingAlive) {
				# add ACK cost
			       	if ($gFoundACK) {
					$result = getCollision(@gSettingVisitedNodes, @gACKPhiNodes); 
					if ($result) {
						$num_insecure_ACK ++; 
					}
					else {
						$num_secure_ACK ++;
					}
				}
				else {
					$num_no_ACK ++;
				}
			}
			$i++;
		}
		#print "setting=$gSettingAlive $gSettingCost\n";
		$cost_pair += $gSettingCost;
	}
	print "nt=$ntests\n";
	printf ("rp=%.5f\n", $num_alive_settings/$ntests);
	printf ("cost=%.5f\n", $cost_pair/$ntests);
	printf ("isack=%.5f\n", $num_insecure_ACK/$ntests);
	printf ("sack=%.5f\n", $num_secure_ACK/$ntests);
	printf ("noack=%.5f\n", $num_no_ACK/$ntests);
	printf ("dist=%.5f\n", sqrt(DISTANCE($src, $dst)));
	printf ("bp=%.5f\n", ($num_alive_settings == 0)? 0 : $num_insecure_ACK/$num_alive_settings);
	return;
	#print the communication cost for each node if necessary
	$cost_pair=0;
	foreach (0..$size-1){
		$cost_pair += $gNodeCost[$_];
		printf ("$_=%.5f\n", $gNodeCost[$_]/$ntests) if ($gNodeCost[$_]);
	}
}

sub getOneSetting () 
{
    my @node_queue = ($src);
    
    while ($#node_queue >= 0) {
	my $cur_node = shift @node_queue;

	#print "curnode=$cur_node:";

	if ($cur_node == $dst) # arrive the destination node
	{
		$gSettingAlive = 1;
		#print "DONE\n"	;
		#print "--------------------------------\n";
		next;
	}
	
	my @cur_bits=@{$gVisited_node{$cur_node}};
	#printArray(@cur_bits); print "\n"; # print out all nodes in current stage
	my @selectedbits = (0..$#cur_bits);
	#random select l bits
	if ($l < $#cur_bits + 1) {	#randomly select l 1's
		foreach (0..$l-1) {
			my $r = int(rand($#selectedbits+1-$_));
			my $tmp = $selectedbits[$_];
			$selectedbits[$_] = $selectedbits[$_+$r];
			$selectedbits[$_+$r] = $tmp;
		}
		splice(@selectedbits, $l); # keep the first $l entries
	}
	#@selectedbits = sort @selectedbits;
		
	foreach (@selectedbits) {
		my $next_node;
		my $next_node_index = DisttoIndex($cur_bits[$_]);
		if ($clockwise) {
		   $next_node = $cur_node + $cur_bits[$_];
		} else {
		    $next_node = $cur_node - $cur_bits[$_];
		    $next_node_index += $gHalfTableSize;
	        }
		$next_node &= $sizemask;

		#my $next_node_index = IDtoIndex($cur_node, $next_node);
		#add the communication cost

		# my $pathref = $array_path[$cur_node][$next_node_index][3];
		# $gNodeCost[$cur_node] ++;
		# map { $gNodeCost[$_]++; } @$pathref;

		$gSettingCost += $array_path[$cur_node][$next_node_index][2];
		my $pathref = $array_path[$cur_node][$next_node_index][3];
		
		if ($array_path[$cur_node][$next_node_index][1]==1) {
			if (!defined($gVisited_node{$next_node})) {
				push @node_queue, $next_node;
				my @ta = @cur_bits;
				splice(@ta, $_, 1);
				$gVisited_node{$next_node} = \@ta;
			}
		}
	}
    }
    return;
}

sub getCollision(\@\@)
{
	#my (@sd, @ds) = @_;
	#my @sd = shift @_;
	#my @ds = shift @_;
	
	my $tmp0 = $_[0];  	#tricky way to pass two array parameters
	my $tmp1 = $_[1];
	my @sd = @$tmp0;	#src and dst are not included
	my @ds = @$tmp1;	#src and dst are not included
	
	return 0 if ($#sd <0 or $#ds<0);
	
	foreach my $i (0..$#ds) {
		foreach my $j (0..$#sd){
			return 1 if (DISTANCE($ds[$i], $sd[$j]) <= $T);
		}	
	}
	
	#printf ("(%.5f)\n", $prob);
	return 0;
}

sub DisttoIndex($)
{
	my ($d) = shift @_;
	my $r = 0;
	my $mask = (1 << $b) - 1;

	while ($d > $mask) {
		$d >>= $b;
		$r ++;
	}
	return ($r << $b) + ($d);
}

sub FindPhysicalPath($$)
{
	my ($src,$dst)= @_;
	return 0 if ($src==$dst); 
	$gComm ++;

	my $min_node=$src;
	my $min_dis=DISTANCE($src, $dst);
	if ($min_dis<=$T) {
		return 0 if (! $array_nodes[$dst][2]); #dst is not alive
		# push @gPath, $dst;
		return 1;
	}
#	my @nodelist = ();
#	foreach my $cur_node (0..$size-1){ #find all alive nodes within T
#		next if ($cur_node == $src);
#		if ((DISTANCE($cur_node, $src)<=$T) && $array_nodes[$cur_node][2]) {
#			push @nodelist, $cur_node;
#		}
#	}
#	print ("nl:$#nodelist ");
#	return 0 if ($#nodelist<0); #no alive nodes within T

	foreach (@{$gNeighbours[$src]}) {
		my $dis=DISTANCE($_,$dst);
		if ($dis<$min_dis){
			$min_node=$_;
			$min_dis=$dis;
		}
	}
	return 0 if ($src==$min_node); # source node is the closest node to dst within T
	push @gPath, $min_node;
	return FindPhysicalPath ($min_node, $dst);
}

sub get_dist($)
{
	my $d=shift;
	my $v = 1;

	%gDist = ();
	while ($d) {
		$gDist{"$v"}=1 if ($d & 1); 
		$d >>= 1;
		$v <<= 1;
	}
}

sub getWeight($)
{
	my $d=shift;
	my $v = 0;
	my $last;
	my $mask = (1 << $b) - 1;

	@gWeight = ();
	while ($d) {
		$last = $d & $mask;
		push @gWeight, ($last << $v) if ($last); 
		$d >>= $b;
		$v += $b;
	}
}

sub getNoneZeroBits($)
{
	my $d=shift;
	my $v = 1;
	my @bitsArray=();
	if ($clockwise)
	{
		$d= ($dst-$d)>0? ($dst-$d): ($dst-$d+$size);
	}else{
		$d= ($d-$dst)>0? ($d-$dst): ($d-$dst+$size);
	}
	
	while ($d) {
		$bitsArray[$#bitsArray+1] = $v if ($d & 1); 
		$d >>= 1;
		$v <<= 1;
	}
	return @bitsArray;
}

#Returns dist^2 for performance
sub DISTANCE(@@)
{
	my ($src,$dst)= @_;
	my $x1= $array_nodes[$src][0];
	my $y1= $array_nodes[$src][1];
	my $x2= $array_nodes[$dst][0];
	my $y2= $array_nodes[$dst][1];
	return (($x1-$x2)*($x1-$x2)+($y1-$y2)*($y1-$y2));
	#printf("(%.2f, %.2f) (%.2f, %.2f) %.2f ", $x1, $y1, $x2, $y2, $t);
}

sub printArray()
{
	print join(" ", @_);
	return;
}

sub getHW($)
{
	my ($dis) = @_;
	my $result=0;
	while ($dis) {
		$result += ($dis & 1);
		$dis >>= 1;
	}
	return $result;
}

sub print_help()
{
	print <<EOH;

Examples: perl simulation.pl -m6 -p0.01 -d4 -l1 -B1 -n100 -r20

perl simulation.pl  [options]

Options:
	-m5 
	-p0.2 
	-d4 
	-l1 
	-r100 	Number of pairs. 0 to enumerate all pairs.
	-n100	Number of tests for each pair. 0 for default values.
	-h 
EOH
	exit;
}
