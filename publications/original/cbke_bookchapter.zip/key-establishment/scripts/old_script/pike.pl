#!/usr/bin/perl
use strict;

#declare subroutines
sub FindPhysicalPath(@@);
sub DISTANCE(@@);
sub get_dist($);
sub printArray;
sub print_help;
sub getHW($);
sub IDtoIndex($$);
sub getOneSetting($$);
sub TryPair();
sub InitialPara($);

#Global varibale definition

my $m = 5; 		#number of bits in the address space
my $size;  		#total number of nodes
my $sizemask;
my $p = 0.1; 		#node failure probability
my $opt_n = 0; 		#number of simulations for each pair
my $opt_f = "";		#input file
my $D = 10;		#Density of nodes (/per unit^2)
my $l = 1;		#outgoing degree
my $T = 1;		#Transmition range (/per unit)
my $a;			#Side of the square
my $r = 1;		#Total number of pairs to choose, r = 0 : check all pairs
my $e;
my %log_2 = (
	1 => 0,
	2 => 1,
	4 => 2,
	8 => 3,
	16 => 4,
	32 => 5,
	64 => 6,
	128 => 7,
	256 => 8,
	512 => 9,
	1024 => 10,
	2048 => 11,
	4096 => 12,
	8192 => 13,
	16384 => 14,
	32768 => 15,
	65536 => 16
);

my @num_tests = 
(0, 	10, 	20, 	60, 	240, 
1200, 	2500, 	5000, 	10000, 	10000, 
10000, 10000, 10000); 

my @array_path;	#Table for all the physical path info
		#@array_path[$i][$j][$k]
		#	$i: source node id
		#	$j: the j_th node which preshare a key with $j. $j=[1..2$m-1]
		#	$k=0, [$k] desination id
		#	$k=1, [$k] the path is alive or not
		#	$k=2, [$k] the communication cost along the path = hops of the path
		#	$k=3, [$k] an array will the all nodes along the path except the source node
my @array_nodes;#Array for all the node info
		#Table for all the node info
		#@array_nodes[$i][$j]
		#	$i: node id
		#	$j: node info
		#	$j=0, [$j] x position
		#	$j=1, [$j] y position
		#	$j=2, [$j] the node is alive or not
		#	$j=3, [$j] comm cost on this node
my @gNodeCost;
my @gPath;
my $gComm;
my %gSelectedPath;
my @gAllPathsInOneSetting;
my $gSettingCost;
my $gSettingAlive;

my @gNeighbours;

#user input
while ($#ARGV >= 0 and $ARGV[0] =~ /^-/) {
	$_ = shift @ARGV;
	/^-m(\d+)/ and ($m = $1, next);
	/^-p(\d+.\d+)/ and ($p = $1, next);
	/^-d(\d+)/i and ($D = $1, next);
	/^-l(\d+)/ and ($l = $1, next);
	/^-r(\d+)/ and ($r = $1, next);
	/^-n(\d+)/ and ($opt_n = $1, next);
	/^-f(.+)/ and ($opt_f = $1, next);
	/^-h$/ and print_help();
	die "Unknown option '$_'\n";
}

if ($opt_f ne "") {

}

die "m cannot be greater than 16.\n" if ($m > 16);

$size = 1 << $m;
$e = 1 << ($m/2);
$sizemask = $size - 1;
$a = sqrt($size/$D); 

printf("config=$m $D $p $l %.5f $r\n", $a);

my @CurrentPath = ();
my $src;
my $dst;
my %gDist;
my $clockwise;

if ($opt_f eq "") {
# Generate the network
foreach (0..$size-1) {
	my @node = ();
	$node[0] = rand($a) ; #random generate x,y position
	$node[1] = rand($a) ; 
	$node[2] = (rand(1)>$p)? 1:0; #alive
	$array_nodes[$_] = \@node;
	printf("$_(%.5f,%.5f,%d)\n", $array_nodes[$_][0], $array_nodes[$_][1], $array_nodes[$_][2]);
}

# find out the alive neighbour for each node
foreach (0..$size-1) {
	$gNeighbours[$_] = [ ];
}

foreach  my $i (0..$size-1) {
	next if (! $array_nodes[$i][2]);  # not alive
	foreach  my $j ($i+1..$size-1) {
		next if (! $array_nodes[$j][2]);
		my $r;
		if (($r = DISTANCE($i, $j)) <= $T) {
			# print "$r = \n";
			push @{$gNeighbours[$i]}, $j;
			push @{$gNeighbours[$j]}, $i;
		}
	}
}

#foreach (0..$size-1) {
#	print "$_: ", $#{$gNeighbours[$_]}, " ";
#	printArray(@{$gNeighbours[$_]});
#	print "\n";
#}

foreach  my $i (0..$size-1) {
	my $x1= int($i/$e);
	my $y1= $i-($x1*$e);
	#printf("Node=%d, x1=%d, y1=%d\n", $i, $x1, $y1);
	foreach  my $j (0..2*$e-3) { # $e-1 nodes in the same row, $e-1 in the same col
		# 0..$e-2 : same row   
		# $e-1..2*$e-3 same col
		my $dstid;
		if ($j<=$e-2) {
			$dstid= ($j<$y1)? ($i-($y1-$j)):($i+($j-$y1)+1);
			#if ($j<$y1) {
			#	$dstid=$i-($y1-$j);
			#}else{
			#	$dstid=$i+($j-$y1)+1;
			#}
		}else{
			my $tempj=$j-$e+1;
			$dstid= ($tempj<$x1)? ($i-($x1-$tempj)*$e):($i+($tempj-$x1+1)*$e);
			#if ($j<$x1) {
			#	$dstid=$i-($x1-$j)*$e;
			#}else{
			#	$dstid=$i+($j-$x1+1)*$e;
			#}
		}
		#printf("src=%d, dst=%d\n", $i, $dstid);
		#my $dis=($j<$m)? 1 << $j : 1 << ($j-$m); #id distancee between src and dst
		#my $dstid = (($j<$m) ? ($i+$dis) : ($i-$dis)) & $sizemask; #calculate the destination id
		@gPath = ();
		$gComm = 0;
		my $found= FindPhysicalPath($i,$dstid);
		my @lPath = @gPath;
		$array_path[$i][$j]=[ $dstid, $found, $gComm, \@lPath ]; 
		printf("$i:$dstid:%d:%d:", $array_path[$i][$j][1], $array_path[$i][$j][2]);
		printArray(@{$array_path[$i][$j][3]});
		print "\n";
	}
}

@gNeighbours = ();

}else{	#read the configurations from the file
	my $left;
	my $right;
	open(INFILE,  $opt_f) or die "Can't open input file: $opt_f!";
	while (<INFILE>) {     # assigns each line in turn to $_
		if ($_ =~ /^(.*)=(.*)$/){
			($left=$1, $right=$2);
			#($nodes[$left] += $right) if ($left =~ /^\d+$/);
			#($count++, next) if ($left =~ /nt/);
			#($sum_rp += $right, next) if ($left =~ /rp/);
			#($sum_ca += $right, next) if ($left =~ /ca/);
			(print $_, InitialPara($right), next) if ($left =~ /config/);
		};
		if ($_ =~ /^(.*)\((.*)\)(.*)$/){
			($left=$1, $right=$2);
			my @nodeinfo = split (",", $right);
			my @node = ();
			$node[0] = $nodeinfo[0];
			$node[1] = $nodeinfo[1];
			$node[2] = $nodeinfo[2];
			$array_nodes[$left] = \@node;
			printf("$left(%.5f,%.5f,%d)\n", $array_nodes[$left][0], $array_nodes[$left][1], $array_nodes[$left][2]);
		};
		if ($_ =~ /:/){
			my @phicalpathinfo = split (":", $_);
			my $cur_node = $phicalpathinfo[0];
			my $next_node = $phicalpathinfo[1];
			my $index_next_node = IDtoIndex($cur_node, $next_node);
			my $path_alive = $phicalpathinfo[2];
			my $comm_cost = $phicalpathinfo[3];
			my @path = split (" ", $phicalpathinfo[4]);
			$array_path[$cur_node][$index_next_node]=[$next_node, $path_alive, $comm_cost, \@path ];
			printf("$cur_node:$next_node:%d:%d:", $array_path[$cur_node][$index_next_node][1], $array_path[$cur_node][$index_next_node][2]);
			printArray(@{$array_path[$cur_node][$index_next_node][3]});
			print "\n";				
		};
	}
	close INFILE;
}

if ($r) {
   foreach (0..$r-1) { 
	$src=int(rand($size));
	while ($array_nodes[$src][2] == 0) {$src=int(rand($size))};
	die if ($array_nodes[$src][2] == 0);
	$dst=int(rand($size));
	while ($dst == $src or $array_nodes[$dst][2] == 0) {$dst=int(rand($size))};
	print ";$_\n";
	TryPair(); 
   }
}
else {
    foreach (0..$size-1) 
    {
	$src = $_;
	next if ($array_nodes[$src][2] == 0);
	foreach (0..$size-1) {
		$dst = $_;
		next if ($src == $dst or $array_nodes[$dst][2] == 0); 
		TryPair();
	}
    }
}

sub InitialPara($){
	my ($config) = @_;
	my @paramters = split (" ", $config);
	$m = $paramters[0];
	$D = $paramters[1];
	$p = $paramters[2];
	$l = $paramters[3];
	$a = $paramters[4];
	$r = $paramters[5];	
	$size = 1 << $m;
	$sizemask = $size - 1;
}

sub TryPair()
{
	print "#$src $dst\n";
	my $x1 = int($src/$e);
	my $y1= $src-($x1*$e);
	my $x2= int($dst/$e);
	my $y2= $dst-($x2*$e);
	
	my $s1_x1 = $x1;
	my $s1_y1 = $y2;
	my $s2_x2 = $x2;
	my $s2_Y2 = $y1;
	
	my $midnode_ID1= $x1*$e+$y2;
	my $midnode_ID2= $x2*$e+$y1;
	
	#printf ("node1=%d, node2=%d\n",$midnode_ID1,$midnode_ID2);
	
	#reset all counters
	my $num_path=2; #two path from src to dst
	my $num_alive_path = 0; # at most 2
	my $cost_pair = 0;
	@gNodeCost = ();
	$gSettingCost = 0;
	@CurrentPath = ($src,$midnode_ID1,$dst);
	$num_alive_path += processLogicPath();
	@CurrentPath = ($src,$midnode_ID2,$dst);
	$num_alive_path += processLogicPath();
	$cost_pair += $gSettingCost;
	
	#foreach (1..$ntests) { #trt one pair for $ntests times, each time generate a setting
		# print "----new setting ($_)----\n";
	#	$gSettingAlive = 0;
	#	$gSettingCost = 0;
	#	%gSelectedPath =();
	#	getOneSetting($src,$hw);
	#	$num_alive_setting ++ if $gSettingAlive;
	#	$cost_pair += $gSettingCost;
	#}
	print "nt=1\n";
	printf ("rp=%.5f\n", $num_alive_path/$num_path);
	$cost_pair=0;
	foreach (0..$size-1){
		$cost_pair += $gNodeCost[$_];
		printf ("$_=%.5f\n", $gNodeCost[$_]) if ($gNodeCost[$_]);
	}
	printf ("ca=%.5f\n", $cost_pair);
}

sub processLogicPath()
{
	foreach my $index (0..$#CurrentPath) {
		my $cur_node = $CurrentPath[$index];
		last if ($cur_node == $dst);
		my $next_node = $CurrentPath[$index+1];
		my $index_next_node = IDtoIndex($cur_node, $next_node);
		#die "IDtoIndex returns wrong value ($index_next_node).\n" 
		#	if ($array_path[$cur_node][$index_next_node][0] != $next_node);
		#if (! defined ($gSelectedPath{$cur_node."-".$next_node})) {
		#	$gSelectedPath{$cur_node."-".$next_node} = 1;
			$gSettingCost += $array_path[$cur_node][$index_next_node][2];
			my $pathref = $array_path[$cur_node][$index_next_node][3];
			$gNodeCost[$cur_node] ++;
			map { $gNodeCost[$_]++; } @$pathref;
		#};
		if (!$array_path[$cur_node][$index_next_node][1]) { # path broken
			#print "$cur_node and $next_node is broken.\n"; 
			return 0;
		}
	}
	return 1;
}

sub IDtoIndex($$)
{
	my ($s, $d) = @_;
	
	my $x1 = int($s/$e);
	my $y1= $s-($x1*$e);
	my $x2= int($d/$e);
	my $y2= $d-($x2*$e);
	
	if ($x1 == $x2) { # same row
		if ($y1 < $y2){
			return ($y2-1);
		}else{
			return ($y2);
		}		
	}
	else { # same col and $y1=$y2
		if ($x1 < $x2){
			return ($x2+$e-2);
		}else{
			return ($x2+$e-1);
		}
	}
}

sub FindPhysicalPath(@@)
{
	my ($src,$dst)= @_;
	return 0 if ($src==$dst); 
	$gComm ++;

	my $min_node=$src;
	my $min_dis=DISTANCE($src, $dst);
	if ($min_dis<=$T) {
		return 0 if (! $array_nodes[$dst][2]); #dst is not alive
		# push @gPath, $dst;
		return 1;
	}
#	my @nodelist = ();
#	foreach my $cur_node (0..$size-1){ #find all alive nodes within T
#		next if ($cur_node == $src);
#		if ((DISTANCE($cur_node, $src)<=$T) && $array_nodes[$cur_node][2]) {
#			push @nodelist, $cur_node;
#		}
#	}
#	print ("nl:$#nodelist ");
#	return 0 if ($#nodelist<0); #no alive nodes within T

	foreach (@{$gNeighbours[$src]}) {
		my $dis=DISTANCE($_,$dst);
		if ($dis<$min_dis){
			$min_node=$_;
			$min_dis=$dis;
		}
	}
	return 0 if ($src==$min_node); # source node is the closest node to dst within T
	push @gPath, $min_node;
	return FindPhysicalPath ($min_node, $dst);
}

sub get_dist($)
{
	my $d=shift;
	my $v = 1;

	%gDist = ();
	while ($d) {
		$gDist{"$v"}=1 if ($d & 1); 
		$d >>= 1;
		$v <<= 1;
	}
}

#Returns dist^2 for performance
sub DISTANCE(@@)
{
	my ($src,$dst)= @_;
	my $x1= $array_nodes[$src][0];
	my $y1= $array_nodes[$src][1];
	my $x2= $array_nodes[$dst][0];
	my $y2= $array_nodes[$dst][1];
	return (($x1-$x2)*($x1-$x2)+($y1-$y2)*($y1-$y2));
	#printf("(%.2f, %.2f) (%.2f, %.2f) %.2f ", $x1, $y1, $x2, $y2, $t);
}

sub printArray()
{
	print join(" ", @_);
	return;
}

sub getHW($)
{
	my ($dis) = @_;
	my $result=0;
	while ($dis) {
		$result += ($dis & 1);
		$dis >>= 1;
	}
	return $result;
}

sub print_help()
{
	print <<EOH;

Examples:

perl simulation.pl  [options]

Options:
	-m5 
	-p0.2 
	-d4 
	-l1 
	-r100 	Number of pairs. 0 to enumerate all pairs.
	-n100	Number of tests for each pair. 0 for default values.
	-h 
EOH
	exit;
}

