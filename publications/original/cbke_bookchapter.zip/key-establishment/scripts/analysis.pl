#!/usr/bin/perl
use strict;

sub printArray;
sub InitialPara($);
sub printTopNodes;

my $m;
my $D;
my $p;
my $l;

my $per=0.1;
my $file;
#user input
# $ARGV[0] =~ /^-/ $ARGV includes the string like -
while ($#ARGV >= 0) {
	last if (! /^-/);
	$_ = shift @ARGV;
}

# open(INFILE,  $_) or die "Can't open input.txt: $!";

my $count=0; #counter the number of the pairs
my $sum_rp=0;
my $sum_ca=0;
my $sum_ap=0;
my $sum_bp=0;
my @nodes=();
my $line;
my %values = ();

while (<>) {     # assigns each line in turn to $_
	if ($_ =~ /^(.*)=(.*)$/) {
		my $left=$1;
		my $right=$2;
		($nodes[$left] += $right, next) if ($left =~ /^\d+$/);
		($count++, next) if ($left =~ /nt/);
		#($sum_rp += $right, next) if ($left =~ /rp/);
		#($sum_ca += $right, next) if ($left =~ /ac/);
		#($sum_ap += $right, next) if ($left =~ /ap/);
		#($sum_bp += $right, next) if ($left =~ /bp/);
		(print($right, "\n"), InitialPara($right), next) if ($left =~ /config/);
		$values{$left} += $right; 
	}; 
}
# close INFILE;

printf ("npairs=%d\n", $count);
#printf ("reliability=%.3f\n", $sum_rp/$count);
#printf ("average_comm_cost=%.3f\n", $sum_ca/$count);
#printf ("average_collision_prob=%.3f\n", $sum_ap/$count);
#printf ("average_collision_prob2=%.3f\n", $sum_bp/$count);
foreach (keys %values) {
	printf("$_=%0.3f\n", $values{$_}/$count);
}
@nodes = sort { $b <=> $a } @nodes; # sort the array by value

my $i = 0;
map {printf ("%4d %.5f\n", $i++, $_/$count); } @nodes;
#printTopNodes ();
#printArray (@nodes);

sub InitialPara($){
	my ($config) = @_;
	my @paramters = split (" ", $config);
	$m = $paramters[0];
	$D = $paramters[1];
	$p = $paramters[2];
	$l = $paramters[3];
	return 1;	
}

sub printTopNodes (){
	my $n= int($per * (1 << $m));
	foreach (0..$n-1){
		print $nodes[$_]." ";
	}
	print "\n";
}

sub printArray()
{
	print join(" ", @_);
	return;
}
