
==========================================================
simulator of CBKE

simulation16.pl is the latest version. The results can be 
analyzed by analysis.pl. A typical run of these two scripts looks
like:  

perl simulation16.pl -m12 -d20 -p0.1 -b1 -r3000 -n200 -l1 >res
./analysis.pl res


==========================================================
sec*

For security properties.

sec1: Output all possible distances: distance, hw(path1), hw(path2).

sec2: Take the output of sec1 and compute the average probability of being compromised.

sec3: Take the output of sec2 and generate a csv file that can be imported into Excel. 


